# WATCHGATE: Module 8 - WebSocket Server for Live Symbolic Feed
# ==============================================================
# This module sets up a WebSocket server that streams real-time symbolic overlay
# results to connected web clients. It's the core communication bridge between
# WATCHGATE processing backend and web-based UI.

import asyncio
import websockets
import json
import base64
import cv2
import numpy as np
from PIL import Image, ImageOps, ImageChops
from skimage.measure import shannon_entropy
from scipy.fftpack import fft2, fftshift
import io

# === FRACTAL & FREQUENCY FUNCTIONS (REUSED) ===
def fractal_score(image: Image.Image) -> float:
    array = np.array(image)
    return shannon_entropy(array)

def extract_dominant_frequencies(image: Image.Image) -> list:
    array = np.array(image)
    f_transform = fftshift(fft2(array))
    magnitude_spectrum = np.abs(f_transform)
    flattened = magnitude_spectrum.flatten()
    sorted_indices = np.argsort(flattened)[-5:]
    dominant_frequencies = [flattened[i] for i in sorted_indices]
    return dominant_frequencies

# === FRAME PROCESSING ===
def process_frame(frame):
    pil_image = Image.fromarray(frame).convert("L")
    mirrored = ImageOps.mirror(pil_image)
    shift = 4
    shifted = ImageChops.offset(mirrored, shift, 0)
    combined = ImageChops.multiply(pil_image, shifted)

    score = fractal_score(combined)
    freq_peaks = extract_dominant_frequencies(combined)

    buffer = io.BytesIO()
    combined.save(buffer, format="JPEG")
    encoded_image = base64.b64encode(buffer.getvalue()).decode("utf-8")

    return {
        "image": encoded_image,
        "score": score,
        "frequencies": freq_peaks
    }

# === LIVE FRAME CAPTURE AND STREAM ===
async def symbolic_stream(websocket, path):
    cap = cv2.VideoCapture(0)
    try:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            processed = process_frame(gray)
            await websocket.send(json.dumps(processed))
            await asyncio.sleep(0.3)
    finally:
        cap.release()

# === SERVER START ===
async def main():
    async with websockets.serve(symbolic_stream, "0.0.0.0", 8765):
        print("[WATCHGATE] WebSocket server started on ws://0.0.0.0:8765")
        await asyncio.Future()  # Run forever

if __name__ == "__main__":
    asyncio.run(main())
