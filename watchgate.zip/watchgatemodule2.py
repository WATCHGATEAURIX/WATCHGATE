# WATCHGATE: Symbolic Extraction Engine (Module 2: Pattern Recognition Layer)
# ========================================================================
# This module is responsible for extracting symbolic shapes, contours,
# and regions of high pattern complexity from processed images or frames.
# It integrates both statistical and visual techniques for emergent pattern detection.

import cv2
import numpy as np
from skimage.feature import canny
from skimage.filters import sobel
from skimage.measure import label, regionprops
from skimage.morphology import closing, square
from skimage.segmentation import clear_border

# === SYMBOLIC REGION DETECTION ===
def extract_symbolic_regions(gray_image):
    # Step 1: Edge Detection
    edges = canny(gray_image, sigma=2.0)

    # Step 2: Morphological Closing
    closed = closing(edges, square(3))

    # Step 3: Clear image border to remove artifacts
    cleared = clear_border(closed)

    # Step 4: Label distinct regions
    label_image = label(cleared)

    symbolic_regions = []
    for region in regionprops(label_image):
        if region.area >= 100:  # Filter out small noise-like regions
            minr, minc, maxr, maxc = region.bbox
            symbolic_regions.append({
                "bbox": (minr, minc, maxr, maxc),
                "area": region.area,
                "centroid": region.centroid
            })

    return symbolic_regions

# === VISUAL OVERLAY FOR VALIDATION ===
def draw_symbolic_overlays(image, regions):
    output = image.copy()
    for reg in regions:
        (minr, minc, maxr, maxc) = reg["bbox"]
        cv2.rectangle(output, (minc, minr), (maxc, maxr), (0, 255, 0), 2)
    return output

# === MAIN ANALYSIS ENTRYPOINT ===
def analyze_frame_for_symbols(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    regions = extract_symbolic_regions(gray)
    overlay_frame = draw_symbolic_overlays(frame, regions)
    return overlay_frame, regions
