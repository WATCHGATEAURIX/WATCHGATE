# WATCHGATE: Module 3 - Symbolic Pattern Classification Engine
# ===============================================================
# This module performs classification and semantic tagging of fractal-symbolic
# overlays using feature analysis from previous stages. It identifies key
# symbolic structures, tracks recurrence, and enables pattern memory.

import numpy as np
import pickle
import os
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# === CONFIGURATION ===
MODEL_SAVE_PATH = "watchgate_classifier_model.pkl"

# === FEATURE EXTRACTOR ===
def extract_features(fractal_data):
    """
    Extracts numerical feature vectors from fractal overlay data.
    :param fractal_data: list of dicts with 'score' and 'frequencies'
    :return: ndarray of shape (n_samples, n_features)
    """
    feature_vectors = []
    for entry in fractal_data:
        for shift_entry in entry[1]:
            vector = [shift_entry['score']] + shift_entry['frequencies']
            feature_vectors.append(vector)
    return np.array(feature_vectors)

# === CLASSIFIER TRAINING ===
def train_symbol_classifier(fractal_data, n_clusters=6):
    features = extract_features(fractal_data)
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)

    model = KMeans(n_clusters=n_clusters, random_state=42)
    model.fit(features_scaled)

    # Save model and scaler
    with open(MODEL_SAVE_PATH, "wb") as f:
        pickle.dump((scaler, model), f)

    return model, scaler

# === CLASSIFICATION / TAGGING ===
def classify_new_frame(fractal_frame_scores):
    with open(MODEL_SAVE_PATH, "rb") as f:
        scaler, model = pickle.load(f)

    frame_features = []
    for entry in fractal_frame_scores:
        vector = [entry['score']] + entry['frequencies']
        frame_features.append(vector)

    features_scaled = scaler.transform(frame_features)
    labels = model.predict(features_scaled)
    return labels

# === SYMBOL TAGS (can be expanded based on empirical meaning) ===
SYMBOL_TAGS = {
    0: "Resonant Core",
    1: "Spiral Artifact",
    2: "Emergent Knot",
    3: "Interference Ridge",
    4: "Nested Pulse",
    5: "Veiled Entity"
}

def map_tags(labels):
    return [SYMBOL_TAGS.get(label, f"Class-{label}") for label in labels]

# === TEST HARNESS ===
if __name__ == "__main__":
    from watchgate_video_overlay import run_watchgate_video

    scores = run_watchgate_video(video_source=0, max_frames=100)
    model, scaler = train_symbol_classifier(scores)

    for frame_index, frame_data in scores:
        labels = classify_new_frame(frame_data)
        tags = map_tags(labels)
        print(f"Frame {frame_index}: Tags: {tags}")
