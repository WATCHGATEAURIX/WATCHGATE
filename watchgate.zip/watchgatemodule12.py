# Module 12: Semantic Pattern Comparison & Historical Match Engine
# ======================================================================
# This module stores symbolic frames and performs semantic pattern matching
# across historical datasets to identify fractal and symbolic recurrences.

import numpy as np
from PIL import Image, ImageChops
import os
import hashlib
from skimage.metrics import structural_similarity as ssim
from typing import List, Tuple

HISTORY_DIR = "watchgate_history_patterns"
MATCH_THRESHOLD = 0.92  # SSIM threshold for symbolic similarity
os.makedirs(HISTORY_DIR, exist_ok=True)

# === HASHING FOR IDENTITY ===
def compute_image_hash(image: Image.Image) -> str:
    resized = image.resize((64, 64)).convert("L")
    data = np.array(resized).flatten()
    return hashlib.md5(data).hexdigest()

# === SSIM BASED COMPARISON ===
def image_similarity(img1: Image.Image, img2: Image.Image) -> float:
    arr1 = np.array(img1.resize((128, 128)).convert("L"))
    arr2 = np.array(img2.resize((128, 128)).convert("L"))
    sim, _ = ssim(arr1, arr2, full=True)
    return sim

# === SAVE TO HISTORY ===
def save_to_history(image: Image.Image, label: str = None) -> str:
    img_hash = compute_image_hash(image)
    filename = f"{label + '_' if label else ''}{img_hash}.png"
    path = os.path.join(HISTORY_DIR, filename)
    image.save(path)
    return path

# === LOAD HISTORY SET ===
def load_history_images() -> List[Tuple[str, Image.Image]]:
    history = []
    for fname in os.listdir(HISTORY_DIR):
        if fname.lower().endswith(".png"):
            path = os.path.join(HISTORY_DIR, fname)
            image = Image.open(path).convert("L")
            history.append((fname, image))
    return history

# === SEARCH FOR MATCHES ===
def find_matches(target_image: Image.Image, threshold: float = MATCH_THRESHOLD) -> List[Tuple[str, float]]:
    matches = []
    for label, hist_img in load_history_images():
        score = image_similarity(target_image, hist_img)
        if score >= threshold:
            matches.append((label, score))
    matches.sort(key=lambda x: -x[1])
    return matches

# === TEST/UTILITY ===
def compare_and_store(image: Image.Image, label: str = None):
    print("--- Checking for symbolic pattern matches ---")
    matches = find_matches(image)
    if matches:
        print("Match found:")
        for match in matches:
            print(f"  {match[0]}: score={match[1]:.4f}")
    else:
        print("No match found. Storing as new pattern.")
        save_to_history(image, label=label)
