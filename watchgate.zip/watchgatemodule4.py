# WATCHGATE Module 4: Live Stream Processor and Web Dashboard Interface
# ============================================================
# Description: Captures video stream, processes symbolic overlay in real time,
# and displays analysis via WebSocket-based web dashboard.

from flask import Flask, render_template, Response
from flask_socketio import SocketIO, emit
import cv2
import threading
import base64
from watchgate_core import process_frame  # Assuming Module 1 methods are imported

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins='*')

video_source = 0  # Default webcam
def capture_stream():
    cap = cv2.VideoCapture(video_source)
    frame_index = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        processed = process_frame(gray, frame_index)

        # Stream representative frame as base64
        _, buffer = cv2.imencode('.jpg', gray)
        frame_b64 = base64.b64encode(buffer).decode('utf-8')

        socketio.emit('frame_data', {
            'index': frame_index,
            'image': frame_b64,
            'scores': processed
        })

        frame_index += 1
        socketio.sleep(0.1)

    cap.release()

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    print("Client connected")

if __name__ == '__main__':
    threading.Thread(target=capture_stream).start()
    socketio.run(app, host='0.0.0.0', port=5000)
