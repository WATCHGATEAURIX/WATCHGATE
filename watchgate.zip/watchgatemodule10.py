# Module 10: WATCHGATE Viral Fractal Pattern Predictor
# ------------------------------------------------------
# Predicts emerging fractal-symbolic behavioral patterns using historical
# recurrences and early warning signs. Adaptive and self-learning.

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import os

MODEL_PATH = "models/viral_predictor_rf.pkl"

# === FEATURE ENGINEERING ===
def extract_features_from_scores(score_set):
    features = []
    for entry in score_set:
        shift = entry["shift"]
        score = entry["score"]
        frequencies = entry["frequencies"]
        features.append([shift, score] + frequencies)
    return np.mean(features, axis=0)

# === TRAINING INTERFACE ===
def train_predictor(score_data, labels):
    X = [extract_features_from_scores(scores) for _, scores in score_data]
    y = labels

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print("Classification Report:\n", classification_report(y_test, y_pred))

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump((model, scaler), MODEL_PATH)
    print(f"Model saved to {MODEL_PATH}")

# === PREDICTION INTERFACE ===
def predict_event(score_data):
    if not os.path.exists(MODEL_PATH):
        raise RuntimeError("Prediction model not found. Please train it first.")

    model, scaler = joblib.load(MODEL_PATH)
    feature_vector = extract_features_from_scores(score_data)
    feature_scaled = scaler.transform([feature_vector])

    prediction = model.predict(feature_scaled)[0]
    probability = model.predict_proba(feature_scaled)[0].max()
    return prediction, probability

# === EXAMPLE USAGE ===
if __name__ == "__main__":
    # Simulated example for test purposes
    from watchgate_module_3 import run_watchgate_video  # Assuming Module 3 outputs score_data
    scores = run_watchgate_video(video_source=0, max_frames=100)

    # Simulated labels (0: neutral, 1: early viral pattern)
    labels = [0 if i < len(scores) // 2 else 1 for i in range(len(scores))]
    train_predictor(scores, labels)

    # Run a prediction on the last pattern
    pred, prob = predict_event(scores[-1][1])
    print(f"Prediction: {pred} (confidence: {prob:.2f})")
