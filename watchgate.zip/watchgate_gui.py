# WATCHGATE GUI Frontend (Module Selector)
# ---------------------------------------------------
# Provides a simple GUI to select modules and input sources,
# and then run the WATCHGATE analysis pipeline accordingly.

import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import os

AVAILABLE_MODULES = ["core", "overlay", "waveform", "authenticity"]

class WatchgateGUI:
    def __init__(self, root):
        self.root = root
        root.title("WATCHGATE Analyzer GUI")

        self.modules = {mod: tk.BooleanVar(value=True) for mod in AVAILABLE_MODULES}
        self.source_path = tk.StringVar()

        self.create_widgets()

    def create_widgets(self):
        tk.Label(self.root, text="Select Source:").pack(pady=(10, 0))
        tk.Entry(self.root, textvariable=self.source_path, width=50).pack()
        tk.Button(self.root, text="Browse", command=self.browse_file).pack(pady=(0, 10))

        tk.Label(self.root, text="Select Modules to Run:").pack()
        for mod, var in self.modules.items():
            tk.Checkbutton(self.root, text=mod.capitalize(), variable=var).pack(anchor="w")

        tk.Button(self.root, text="Run WATCHGATE", command=self.run_watchgate).pack(pady=20)

    def browse_file(self):
        path = filedialog.askopenfilename(filetypes=[("Video or Image Files", "*.mp4 *.avi *.jpg *.png")])
        if path:
            self.source_path.set(path)

    def run_watchgate(self):
        selected_modules = [m for m, v in self.modules.items() if v.get()]
        if not selected_modules:
            messagebox.showwarning("No Modules Selected", "Please select at least one module.")
            return

        if not self.source_path.get():
            messagebox.showwarning("No Source", "Please select an image or video source file.")
            return

        command = ["python", "watchgate_test_suite.py", "--source", self.source_path.get(), "--modules"] + selected_modules
        try:
            subprocess.run(command, check=True)
            messagebox.showinfo("Success", "WATCHGATE analysis completed successfully.")
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Execution Error", f"An error occurred while running WATCHGATE:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = WatchgateGUI(root)
    root.mainloop()
