# Module 19: External Signal & API Ingestion Layer
# ================================================
# Ingests external APIs, signals, IoT feeds, or satellite intelligence
# for overlay into the WATCHGATE symbolic-fractal frame analysis.

import requests
import json
import time

EXTERNAL_ENDPOINTS = [
    {
        "name": "GeoFractalSentinel",
        "url": "https://api.example.com/geofractal/stream",
        "auth": "Bearer <TOKEN>",
    },
    {
        "name": "CivicWaveFeed",
        "url": "https://feeds.example.org/civic/waves",
        "auth": None,
    },
]

POLL_INTERVAL = 60  # seconds

# === FETCH EXTERNAL SIGNAL ===
def fetch_signal(endpoint):
    headers = {"Authorization": endpoint["auth"]} if endpoint["auth"] else {}
    try:
        response = requests.get(endpoint["url"], headers=headers, timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"[ERROR] Failed to fetch from {endpoint['name']}: {e}")
        return None

# === PARSE SIGNAL PAYLOAD ===
def parse_signal_payload(payload):
    symbolic_events = []
    if isinstance(payload, list):
        for entry in payload:
            symbolic_events.append({
                "timestamp": entry.get("timestamp"),
                "location": entry.get("region"),
                "intensity": entry.get("symbolic_intensity", 0.0),
                "tags": entry.get("tags", [])
            })
    return symbolic_events

# === MAIN LOOP ===
def poll_external_feeds():
    while True:
        for ep in EXTERNAL_ENDPOINTS:
            data = fetch_signal(ep)
            if data:
                events = parse_signal_payload(data)
                print(f"[INFO] {ep['name']} - {len(events)} symbolic events received")
                # Pass to symbolic fusion layer or store
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    poll_external_feeds()
