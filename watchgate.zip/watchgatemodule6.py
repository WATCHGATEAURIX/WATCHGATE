# WATCHGATE: Module 6 - WebSocket Live Stream Handler
# =====================================================
# Real-time communication between frontend and backend using WebSocket
# This module handles symbolic data stream updates to connected clients.

import asyncio
import websockets
import json
import threading
import random

connected_clients = set()

# Simulate symbolic fractal events (you will later connect this to actual stream analysis)
async def fractal_event_simulator():
    while True:
        if connected_clients:
            update = {
                "event": "symbolic_overlay_update",
                "payload": {
                    "timestamp": asyncio.get_event_loop().time(),
                    "intensity": round(random.uniform(0.2, 1.0), 3),
                    "dominant_shift": random.choice([-8, -4, 0, 4, 8]),
                    "frequency_peaks": [round(random.uniform(100, 1000), 2) for _ in range(3)]
                }
            }
            message = json.dumps(update)
            await asyncio.gather(*(client.send(message) for client in connected_clients))
        await asyncio.sleep(1.5)

async def handler(websocket, path):
    connected_clients.add(websocket)
    try:
        async for message in websocket:
            print(f"[WebSocket Received] {message}")
            # You can implement message-specific reactions here
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        connected_clients.remove(websocket)

# Run both simulator and server in asyncio
async def main():
    server = await websockets.serve(handler, "localhost", 8765)
    print("WebSocket server started on ws://localhost:8765")
    await fractal_event_simulator()
    await server.wait_closed()

# Run in separate thread so other servers (Flask) can run in parallel
def start_websocket_server():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(main())

if __name__ == "__main__":
    thread = threading.Thread(target=start_websocket_server)
    thread.start()
