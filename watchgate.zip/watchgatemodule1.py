# WATCHGATE: Symbolic Fractal Video Stream Processor (Phase 3: Waveform Analysis)
# ======================================================================
# This module processes video streams frame-by-frame to detect symbolic fractal patterns.
# It overlays mirrored versions, applies a multiply effect, computes a fractal proxy,
# and now includes frequency domain (waveform) analysis of symbolic structures.

import cv2
import numpy as np
import os
from PIL import Image, ImageOps, ImageChops
from skimage.measure import shannon_entropy
from scipy.fftpack import fft2, fftshift
from datetime import datetime
import argparse

# === CONFIGURATION ===
VIDEO_SOURCE = 0  # Default to webcam; override via CLI
OUTPUT_DIR = "watchgate_video_output"
FRAME_SAMPLE_RATE = 5  # Process every 5th frame
SHIFT_PIXELS = list(range(-10, 11, 2))  # Shift range for overlay effect
MAX_FRAMES = 300  # Stop after processing this many frames

os.makedirs(OUTPUT_DIR, exist_ok=True)

# === FRACTAL SCORE COMPUTATION ===
def fractal_score(image: Image.Image) -> float:
    array = np.array(image)
    return shannon_entropy(array)

# === FREQUENCY DOMAIN ANALYSIS ===
def extract_dominant_frequencies(image: Image.Image) -> list:
    array = np.array(image)
    f_transform = fftshift(fft2(array))
    magnitude_spectrum = np.abs(f_transform)
    flattened = magnitude_spectrum.flatten()
    sorted_indices = np.argsort(flattened)[-5:]  # Get top 5 peaks
    dominant_frequencies = [flattened[i] for i in sorted_indices]
    return dominant_frequencies

# === SYMBOLIC FRAME PROCESSING ===
def process_frame(frame, frame_index):
    pil_image = Image.fromarray(frame).convert("L")  # Convert to grayscale
    mirrored = ImageOps.mirror(pil_image)

    frame_scores = []
    for shift in SHIFT_PIXELS:
        shifted = ImageChops.offset(mirrored, shift, 0)
        combined = ImageChops.multiply(pil_image, shifted)
        score = fractal_score(combined)
        freq_peaks = extract_dominant_frequencies(combined)

        frame_scores.append({
            "shift": shift,
            "score": score,
            "frequencies": freq_peaks
        })

        if abs(shift) == 4:  # Save representative frame
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{OUTPUT_DIR}/frame_{frame_index}_shift_{shift:+d}.png"
            combined.save(filename)

    return frame_scores

# === MAIN VIDEO LOOP ===
def run_watchgate_video(video_source=0, max_frames=300):
    cap = cv2.VideoCapture(video_source)
    frame_index = 0
    all_scores = []

    while cap.isOpened() and frame_index < max_frames:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index % FRAME_SAMPLE_RATE == 0:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            pil_frame = Image.fromarray(gray_frame)
            scores = process_frame(np.array(pil_frame), frame_index)
            all_scores.append((frame_index, scores))

        frame_index += 1

    cap.release()
    print(f"WATCHGATE video processing complete. Frames processed: {frame_index}")

    return all_scores

# === CLI INTERFACE ===
def main():
    parser = argparse.ArgumentParser(description="WATCHGATE CLI: Fractal Video Symbolic Analyzer")
    parser.add_argument("--source", type=str, default="0", help="Video source (0 for webcam or path to video file)")
    parser.add_argument("--max_frames", type=int, default=300, help="Maximum number of frames to process")
    args = parser.parse_args()

    source = int(args.source) if args.source.isdigit() else args.source
    scores = run_watchgate_video(video_source=source, max_frames=args.max_frames)

    print("Final fractal scores per frame:")
    for fidx, score_set in scores:
        print(f"Frame {fidx}:")
        for entry in score_set:
            print(f"  Shift {entry['shift']:>+3}: Score={entry['score']:.3f}, Frequencies={entry['frequencies']}")

if __name__ == "__main__":
    main()
