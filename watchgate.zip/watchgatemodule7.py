# Module 7: Video File Processor
# ==============================
# This module allows users to analyze stored video files (MP4, AVI, etc.)
# using the same symbolic and fractal overlay pipeline as the live stream.

import os
import cv2
import numpy as np
from PIL import Image, ImageOps, ImageChops
from skimage.measure import shannon_entropy
from scipy.fftpack import fft2, fftshift
from datetime import datetime

VIDEO_OUTPUT_DIR = "watchgate_file_output"
os.makedirs(VIDEO_OUTPUT_DIR, exist_ok=True)

SHIFT_PIXELS = list(range(-10, 11, 2))
FRAME_SAMPLE_RATE = 5


def fractal_score(image: Image.Image) -> float:
    array = np.array(image)
    return shannon_entropy(array)


def extract_dominant_frequencies(image: Image.Image) -> list:
    array = np.array(image)
    f_transform = fftshift(fft2(array))
    magnitude_spectrum = np.abs(f_transform)
    flattened = magnitude_spectrum.flatten()
    sorted_indices = np.argsort(flattened)[-5:]
    dominant_frequencies = [flattened[i] for i in sorted_indices]
    return dominant_frequencies


def process_video_file(path_to_video, max_frames=300):
    cap = cv2.VideoCapture(path_to_video)
    frame_index = 0
    all_results = []

    while cap.isOpened() and frame_index < max_frames:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index % FRAME_SAMPLE_RATE == 0:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            pil_image = Image.fromarray(gray_frame)
            mirrored = ImageOps.mirror(pil_image)

            for shift in SHIFT_PIXELS:
                shifted = ImageChops.offset(mirrored, shift, 0)
                combined = ImageChops.multiply(pil_image, shifted)
                score = fractal_score(combined)
                freqs = extract_dominant_frequencies(combined)

                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{VIDEO_OUTPUT_DIR}/file_frame_{frame_index}_shift_{shift:+d}.png"
                combined.save(filename)

                all_results.append({
                    "frame": frame_index,
                    "shift": shift,
                    "score": score,
                    "frequencies": freqs,
                    "image_path": filename
                })

        frame_index += 1

    cap.release()
    return all_results


# CLI Test Runner
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="WATCHGATE Module 7: Process Video File")
    parser.add_argument("--file", required=True, help="Path to input video file")
    parser.add_argument("--max_frames", type=int, default=300, help="Max number of frames to process")
    args = parser.parse_args()

    results = process_video_file(args.file, max_frames=args.max_frames)
    for r in results:
        print(f"Frame {r['frame']} Shift {r['shift']:>+3}: Score={r['score']:.3f}, Freqs={r['frequencies']}")
