
import subprocess



a1 = 100
a2 = 200
info = 'emotion'


def runit():
	command = ["python","test2.py"]

	try:
		result = subprocess.run(command, capture_output=True, text=True, check=True)
		print("From sub\n", result.stdout)

	except subprocess.CalledProcessError as e:
		print("Error was found\n", e.stderr)






class kolpak:
	def zup():
		print(f'-----------------')
		print(f'---------{info}--------')
		return a1+598

	def zup1():
		a3 =a1+a2+50000





		return a3+minus()

def minus():
	return a1-a2

def abra():
	print(f'abra() function {kolpak.zup1()}')
	return 'sss'

if __name__ == "__main__":
		d = abra()
		runit()
		print(f'{d}')