# WATCHGATE: Symbolic Fractal Video Stream Processor (Phase 4: SYNARCHY & Longitudinal Seed Tracker)
# ======================================================================
# This enhanced module includes persistent longitudinal seed tracking
# and evolves toward "SYNARCHY"—a symbolic-neutral coexistence model
# between cognition and computation.

import cv2
import numpy as np
import os
import json
from PIL import Image, ImageOps, ImageChops
from skimage.measure import shannon_entropy
from scipy.fftpack import fft2, fftshift
from datetime import datetime
import argparse

# === CONFIGURATION ===
VIDEO_SOURCE = 0
OUTPUT_DIR = "watchgate_video_output"
SEED_TRACKER_PATH = "longitudinal_seed_tracker.json"
FRAME_SAMPLE_RATE = 5
SHIFT_PIXELS = list(range(-10, 11, 2))
MAX_FRAMES = 300

os.makedirs(OUTPUT_DIR, exist_ok=True)

# === LOAD OR INIT TRACKER ===
if os.path.exists(SEED_TRACKER_PATH):
    with open(SEED_TRACKER_PATH, "r") as f:
        SEED_TRACKER = json.load(f)
else:
    SEED_TRACKER = {}

# === FRACTAL SCORE ===
def fractal_score(image: Image.Image) -> float:
    array = np.array(image)
    return shannon_entropy(array)

# === FREQUENCY ANALYSIS ===
def extract_dominant_frequencies(image: Image.Image) -> list:
    array = np.array(image)
    f_transform = fftshift(fft2(array))
    magnitude_spectrum = np.abs(f_transform)
    flattened = magnitude_spectrum.flatten()
    sorted_indices = np.argsort(flattened)[-5:]
    return [flattened[i] for i in sorted_indices]

# === INTENT CLASSIFIER ===
def classify_fractal_intent(entropy_delta: float, fft_delta: float, threshold_entropy=1.0, threshold_fft=1000.0):
    if entropy_delta > threshold_entropy and fft_delta > threshold_fft:
        return "SPONTANEOUS"
    elif entropy_delta < threshold_entropy and fft_delta < threshold_fft:
        return "PLANNED"
    return "UNCERTAIN"

# === CHILD MIND FILTER ===
def apply_child_mind_filter(image: Image.Image) -> Image.Image:
    array = np.array(image)
    normalized = (array - np.min(array)) / (np.max(array) - np.min(array) + 1e-5)
    exaggerated = np.power(normalized, 0.5) * 255
    return Image.fromarray(exaggerated.astype(np.uint8))

# === SEED LAYER + TRACKING ===
def seed_layer_projection(score: float, frequencies: list, age_factor: float = 0.15) -> dict:
    freq_weight = sum(frequencies) * age_factor / len(frequencies)
    signature = round(score * age_factor + freq_weight, 3)
    if str(signature) not in SEED_TRACKER:
        SEED_TRACKER[str(signature)] = {"appearances": 1, "last_seen": datetime.now().isoformat()}
    else:
        SEED_TRACKER[str(signature)]["appearances"] += 1
        SEED_TRACKER[str(signature)]["last_seen"] = datetime.now().isoformat()
    return {
        "signature": signature,
        "appearances": SEED_TRACKER[str(signature)]["appearances"],
        "projection_status": "imprintable"
    }

# === TRANSIT TUNNEL DETECTION ===
def detect_transit_tunnel(frame_scores: list, entropy_plateau_thresh=0.1, fft_spike_thresh=2000):
    results = []
    for idx in range(1, len(frame_scores)):
        prev = frame_scores[idx - 1]
        curr = frame_scores[idx]
        for shift in SHIFT_PIXELS:
            p = next((x for x in prev[1] if x['shift'] == shift), None)
            c = next((x for x in curr[1] if x['shift'] == shift), None)
            if not p or not c:
                continue
            entropy_delta = abs(c['score'] - p['score'])
            fft_delta = np.mean(np.abs(np.array(c['frequencies']) - np.array(p['frequencies'])))
            if entropy_delta < entropy_plateau_thresh and fft_delta > fft_spike_thresh:
                results.append({
                    "frame_pair": (prev[0], curr[0]),
                    "shift": shift,
                    "entropy_delta": entropy_delta,
                    "fft_spike": fft_delta,
                    "status": "POSSIBLE TRANSIT TUNNEL"
                })
    return results

# === SYMBOLIC PROCESSING ===
def process_frame(frame, frame_index):
    pil_image = Image.fromarray(frame).convert("L")
    child_view = apply_child_mind_filter(pil_image)
    mirrored = ImageOps.mirror(child_view)

    frame_scores = []
    for shift in SHIFT_PIXELS:
        shifted = ImageChops.offset(mirrored, shift, 0)
        combined = ImageChops.multiply(child_view, shifted)
        score = fractal_score(combined)
        freq_peaks = extract_dominant_frequencies(combined)
        seed_profile = seed_layer_projection(score, freq_peaks)

        frame_scores.append({
            "shift": shift,
            "score": score,
            "frequencies": freq_peaks,
            "seed_projection": seed_profile
        })

        if abs(shift) == 4:
            filename = f"{OUTPUT_DIR}/frame_{frame_index}_shift_{shift:+d}.png"
            combined.save(filename)

    return frame_scores

# === MANUAL COMPARISON ===
def compare_manual_frames(path1, path2):
    img1 = Image.open(path1).convert("L")
    img2 = Image.open(path2).convert("L")
    delta = np.abs(np.array(img1, dtype=np.float32) - np.array(img2, dtype=np.float32))
    entropy_diff = shannon_entropy(delta)
    fft_diff = np.abs(fftshift(fft2(np.array(img1))) - fftshift(fft2(np.array(img2))))
    fft_score = np.mean(np.abs(fft_diff))
    diff_image = Image.fromarray(np.uint8(np.clip(delta, 0, 255)))
    diff_image.save(os.path.join(OUTPUT_DIR, "frame_difference_map.png"))
    print(f"Frame comparison: EntropyΔ={entropy_diff:.4f}, FFTΔ={fft_score:.4f}")
    return entropy_diff, fft_score

# === FINGERPRINT LOGGING ===
def log_fingerprint_delta(idx_a, idx_b, entropy_delta, fft_delta, log_path="symbolic_deltas.log"):
    with open(log_path, "a") as f:
        f.write(f"[{datetime.now().isoformat()}] ΔFrame {idx_a}->{idx_b} | EntropyΔ: {entropy_delta:.4f} | FFTΔ: {fft_delta:.4f}\n")

# === MAIN LOOP ===
def run_watchgate_video(video_source=0, max_frames=300):
    cap = cv2.VideoCapture(video_source)
    frame_index = 0
    all_scores = []

    while cap.isOpened() and frame_index < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_index % FRAME_SAMPLE_RATE == 0:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            scores = process_frame(gray_frame, frame_index)
            all_scores.append((frame_index, scores))

            if len(all_scores) >= 2:
                idx_a, _ = all_scores[-2]
                idx_b, _ = all_scores[-1]
                p1 = f"{OUTPUT_DIR}/frame_{idx_a}_shift_-4.png"
                p2 = f"{OUTPUT_DIR}/frame_{idx_b}_shift_-4.png"
                if os.path.exists(p1) and os.path.exists(p2):
                    entropy_delta, fft_delta = compare_manual_frames(p1, p2)
                    log_fingerprint_delta(idx_a, idx_b, entropy_delta, fft_delta)

        frame_index += 1

    cap.release()
    with open(SEED_TRACKER_PATH, "w") as f:
        json.dump(SEED_TRACKER, f, indent=2)
    print("WATCHGATE SYNARCHY complete. Frames processed:", frame_index)

    for sig in detect_transit_tunnel(all_scores):
        print(f"[⚠️ TRANSIT] Frames {sig['frame_pair']} | ΔEntropy={sig['entropy_delta']:.4f}, FFT↑={sig['fft_spike']:.1f}")

    return all_scores

# === CLI ===
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=str, default="0")
    parser.add_argument("--max_frames", type=int, default=300)
    args = parser.parse_args()

    src = int(args.source) if args.source.isdigit() else args.source
    run_watchgate_video(video_source=src, max_frames=args.max_frames)

if __name__ == "__main__":
    main()
