from pytube import YouTube

url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
yt = YouTube(url)
stream = yt.streams.filter(file_extension='mp4', progressive=True).first()
stream.download(filename='test_video.mp4')
