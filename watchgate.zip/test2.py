

# test as a module
a =1

def production():
	print(f'----------------- {a}')
	return 'bromance'

if __name__ == "__main__":
		b = production()
		print(f'----------------- {b}')