# WATCHGATE TEST SUITE ORCHESTRATOR
# ====================================
# This script allows selective testing of WATCHGATE modules against
# static images, video files, or live streams.
# python watchgate_test_suite.py --source myvideo.mp4 --modules core overlay waveform


import argparse
import os
import cv2
from pathlib import Path

# Mock import placeholders — replace with actual module calls
from watchgatemodule1 import process_video_stream
from module_04_overlay_engine import apply_symbolic_overlay
from module_06_waveform_analyzer import analyze_frequency_domain
from watchgatemodule9 import verify_authenticity

# Add more imports as modules become available

# === MODULE REGISTRY ===
MODULE_FUNCTIONS = {
    "core": process_video_stream,
    "overlay": apply_symbolic_overlay,
    "waveform": analyze_frequency_domain,
    "authenticity": verify_authenticity,
    # Extendable: more modules can be added here
}

# === INPUT VALIDATION ===
def is_video_file(path):
    return Path(path).suffix.lower() in [".mp4", ".avi", ".mov"]

def is_image_file(path):
    return Path(path).suffix.lower() in [".jpg", ".png", ".jpeg", ".bmp"]

# === MAIN TEST ROUTINE ===
def run_tests(source, modules):
    print(f"Running WATCHGATE test suite on source: {source}")
    
    # Load source
    if source == "0":
        capture = cv2.VideoCapture(0)
        input_type = "live"
    elif is_video_file(source):
        capture = cv2.VideoCapture(source)
        input_type = "video"
    elif is_image_file(source):
        frame = cv2.imread(source)
        input_type = "image"
    else:
        raise ValueError("Unsupported input source")

    # Process image or frames depending on type
    if input_type == "image":
        print("\n[INPUT] Loaded static image")
        frame = cv2.imread(source)
        for mod in modules:
            print(f"\n[MODULE] Executing '{mod}'")
            MODULE_FUNCTIONS[mod](frame)

    else:
        print("\n[INPUT] Beginning frame-by-frame processing")
        frame_idx = 0
        while capture.isOpened():
            ret, frame = capture.read()
            if not ret:
                break

            for mod in modules:
                print(f"\n[FRAME {frame_idx}] [MODULE] '{mod}'")
                MODULE_FUNCTIONS[mod](frame)

            frame_idx += 1
            if frame_idx >= 100:
                break
        capture.release()

# === ENTRY POINT ===
def main():
    parser = argparse.ArgumentParser(description="WATCHGATE Modular Test Suite")
    parser.add_argument("--source", required=True, help="Input: webcam (0), video file, or image")
    parser.add_argument("--modules", nargs="+", required=True,
                        help="Modules to test: core, overlay, waveform, authenticity, etc.")
    args = parser.parse_args()

    run_tests(args.source, args.modules)

if __name__ == "__main__":
    main()
