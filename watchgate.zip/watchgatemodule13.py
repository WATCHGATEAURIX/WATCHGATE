# Module 13: Symbolic Threat Index and Alert Propagation System
# =============================================================
# This module generates a symbolic threat index score per region/frame/time interval
# and triggers a configurable alerting and propagation mechanism (console, socket, file, etc.)

import json
import time
import numpy as np
from collections import deque

# === CONFIG ===
THREAT_HISTORY_WINDOW = 10  # Number of previous threat scores to consider
THREAT_ALERT_THRESHOLD = 0.75  # Average score over window that triggers alert
THREAT_DECAY = 0.9  # How fast the past threat score decays

class ThreatAnalyzer:
    def __init__(self):
        self.threat_history = deque(maxlen=THREAT_HISTORY_WINDOW)

    def compute_threat_score(self, frame_data):
        # frame_data is a list of symbolic scores and pattern matches
        entropy_scores = [entry['score'] for entry in frame_data]
        frequency_spikes = [max(entry['frequencies']) for entry in frame_data if entry['frequencies']]

        mean_entropy = np.mean(entropy_scores) if entropy_scores else 0
        mean_frequency = np.mean(frequency_spikes) if frequency_spikes else 0

        # Heuristic score: Entropy × log(Frequency peak)
        score = mean_entropy * np.log1p(mean_frequency)
        return min(score / 10.0, 1.0)  # Normalize to 0-1

    def update_and_check(self, frame_data):
        score = self.compute_threat_score(frame_data)
        if self.threat_history:
            score = score + THREAT_DECAY * self.threat_history[-1]  # decay+boost
        self.threat_history.append(score)

        average_threat = np.mean(self.threat_history)
        if average_threat > THREAT_ALERT_THRESHOLD:
            self.trigger_alert(score, average_threat)

        return score, average_threat

    def trigger_alert(self, current_score, avg_score):
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        alert = {
            "time": timestamp,
            "current_score": round(current_score, 3),
            "average": round(avg_score, 3),
            "message": "SYMBOLIC FRACTAL ALERT: Potential destabilization zone detected"
        }
        print("[WATCHGATE ALERT]", json.dumps(alert, indent=2))
        # Future extension: send via WebSocket or write to file

# === Example test ===
if __name__ == "__main__":
    analyzer = ThreatAnalyzer()
    dummy_frames = [[{"score": np.random.rand(), "frequencies": list(np.random.rand(5))}] for _ in range(20)]
    for frame in dummy_frames:
        score, avg = analyzer.update_and_check(frame)
        print(f"Current Score: {score:.3f}, Avg: {avg:.3f}")
