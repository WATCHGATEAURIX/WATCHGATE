import numpy as np
from PIL import Image, ImageOps, ImageChops
from skimage.measure import shannon_entropy
from scipy.fftpack import fft2, fftshift
import matplotlib.pyplot as plt
import os

# Create output directory
output_dir = "watchgate_test_output"
video_path ="998.mp4"
os.makedirs(output_dir, exist_ok=True)

# Fractal and frequency analysis helpers
def fractal_score(image: Image.Image) -> float:
    return shannon_entropy(np.array(image))

def extract_dominant_frequencies(image: Image.Image, top_n=5) -> list:
    arr = np.array(image)
    spectrum = np.abs(fftshift(fft2(arr)))
    flattened = spectrum.flatten()
    indices = np.argsort(flattened)[-top_n:]
    return [flattened[i] for i in indices]

# Mirrored overlay and analysis
def analyze_frame(pil_img, shift_values=range(-10, 11, 2)):
    mirrored = ImageOps.mirror(pil_img.convert("L"))
    results = []
    for shift in shift_values:
        shifted = ImageChops.offset(mirrored, shift, 0)
        combined = ImageChops.multiply(pil_img.convert("L"), shifted)
        entropy = fractal_score(combined)
        freqs = extract_dominant_frequencies(combined)
        results.append((shift, entropy, freqs))
    return results

# Extract and process each frame
from moviepy import VideoFileClip

clip = VideoFileClip(video_path)
frames_to_analyze = []
step = max(1, int(clip.fps // 5))  # Sample every few frames

for i, frame in enumerate(clip.iter_frames()):
    if i % step == 0:
        pil_frame = Image.fromarray(frame)
        results = analyze_frame(pil_frame)
        frames_to_analyze.append({
            "frame_index": i,
            "analysis": results
        })
    if i > 30:
        break  # Limit to duration of clip

clip.reader.close()

frames_to_analyze[:2]  # Show preview of the first few results
