# WATCHGATE MODULE 11: SYMBOLIC ANOMALY MAP & CROSS-SCALE ENTITY TRACKER
# ======================================================================
# Purpose:
# This module analyzes symbolic and fractal features across multiple spatial and temporal scales.
# It generates a symbolic anomaly map and tracks persistent or emergent symbolic entities over time.

import numpy as np
import cv2
from scipy.ndimage import gaussian_filter
from skimage.feature import blob_dog
from skimage.measure import label, regionprops
import matplotlib.pyplot as plt
import os

# === CONFIGURATION ===
FRAME_HISTORY_LENGTH = 30
ENTITY_PERSISTENCE_THRESHOLD = 5
ANOMALY_INTENSITY_THRESHOLD = 0.75
OUTPUT_DIR = "watchgate_entity_tracking"
os.makedirs(OUTPUT_DIR, exist_ok=True)

frame_history = []
entity_tracker = {}

# === SYMBOLIC ANOMALY MAP ===
def generate_anomaly_map(frames):
    avg_frame = np.mean(frames, axis=0)
    blurred = gaussian_filter(avg_frame, sigma=2)
    norm = (blurred - np.min(blurred)) / (np.max(blurred) - np.min(blurred))
    anomaly_map = norm > ANOMALY_INTENSITY_THRESHOLD
    return anomaly_map.astype(np.uint8)

# === BLOB TRACKING FOR SYMBOLIC ENTITIES ===
def detect_symbolic_entities(frame):
    blobs = blob_dog(frame, min_sigma=1, max_sigma=5, threshold=0.02)
    return blobs

def update_entity_tracker(blobs, frame_idx):
    for i, blob in enumerate(blobs):
        y, x, r = blob
        entity_tracker[f"{frame_idx}_{i}"] = {
            "position": (x, y),
            "radius": r,
            "frame": frame_idx
        }

# === ENTITY VISUALIZATION ===
def save_entity_map(anomaly_map, blobs, frame_idx):
    fig, ax = plt.subplots()
    ax.imshow(anomaly_map, cmap='gray')
    for blob in blobs:
        y, x, r = blob
        circle = plt.Circle((x, y), r, color='red', linewidth=1.5, fill=False)
        ax.add_patch(circle)
    ax.set_title(f"Symbolic Entities Frame {frame_idx}")
    plt.axis('off')
    output_path = os.path.join(OUTPUT_DIR, f"symbolic_entities_{frame_idx}.png")
    plt.savefig(output_path)
    plt.close()

# === MAIN TRACKING LOOP ===
def process_symbolic_tracking(frames):
    for idx, frame in enumerate(frames):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        frame_history.append(gray)
        if len(frame_history) > FRAME_HISTORY_LENGTH:
            frame_history.pop(0)

        if len(frame_history) == FRAME_HISTORY_LENGTH:
            anomaly_map = generate_anomaly_map(frame_history)
            blobs = detect_symbolic_entities(anomaly_map)
            update_entity_tracker(blobs, idx)
            save_entity_map(anomaly_map, blobs, idx)
    
    print(f"Processed {len(frames)} frames. Entities tracked: {len(entity_tracker)}")
    return entity_tracker

# Integration point: expects `frames` to be a list of np.ndarray from a video or feed.
# Example:
#   frames = load_video_frames("video.mp4")
#   tracked = process_symbolic_tracking(frames)
