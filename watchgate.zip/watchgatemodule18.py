# WATCHGATE MODULE 18: Anomaly Escalation Response Engine
# ----------------------------------------------------------
# Purpose: Classify anomaly types detected in symbolic overlays and waveform analytics,
# escalate critical patterns, and trigger external hooks for alerting or adaptive system response.

import json
import requests
from datetime import datetime

# === CONFIGURATION ===
ALERT_WEBHOOK_URL = "http://localhost:8080/alert"  # Can be replaced with a real system endpoint
ESCALATION_LOG = "escalation_events.log"

# === THRESHOLDS ===
FRACTAL_SCORE_THRESHOLD = 7.5
SYNCHRONIZED_PEAKS_THRESHOLD = 4
FREQUENCY_ALERT_ZONE = (0.95, 1.05)  # Normalized range considered anomalous if breached

# === ESCALATION LEVELS ===
ESCALATION_MAP = {
    "low": 1,
    "moderate": 2,
    "high": 3,
    "critical": 4
}

# === CLASSIFY ANOMALY ===
def classify_anomaly(score, sync_count, dominant_freqs):
    anomaly_type = "none"
    escalation = "low"

    if score > FRACTAL_SCORE_THRESHOLD:
        anomaly_type = "fractal_density_peak"
        escalation = "moderate"

    if sync_count >= SYNCHRONIZED_PEAKS_THRESHOLD:
        anomaly_type = "wave_sync_convergence"
        escalation = "high"

    for freq in dominant_freqs:
        norm_freq = freq / max(dominant_freqs)
        if norm_freq < FREQUENCY_ALERT_ZONE[0] or norm_freq > FREQUENCY_ALERT_ZONE[1]:
            anomaly_type = "frequency_outlier"
            escalation = "critical"
            break

    return anomaly_type, escalation

# === ESCALATION EVENT TRIGGER ===
def trigger_escalation(frame_index, score, sync_count, dominant_freqs):
    anomaly_type, escalation = classify_anomaly(score, sync_count, dominant_freqs)

    if anomaly_type == "none":
        return None

    event = {
        "timestamp": datetime.utcnow().isoformat(),
        "frame_index": frame_index,
        "anomaly": anomaly_type,
        "escalation_level": escalation,
        "details": {
            "score": score,
            "sync_peaks": sync_count,
            "dominant_frequencies": dominant_freqs
        }
    }

    with open(ESCALATION_LOG, "a") as log_file:
        log_file.write(json.dumps(event) + "\n")

    try:
        response = requests.post(ALERT_WEBHOOK_URL, json=event)
        if response.status_code != 200:
            print("[WATCHGATE] Warning: Alert webhook failed.")
    except Exception as e:
        print(f"[WATCHGATE] Alert dispatch error: {e}")

    print(f"[WATCHGATE] Escalation triggered: {anomaly_type} at level {escalation}")
    return event

# === EXAMPLE USAGE ===
if __name__ == "__main__":
    example = trigger_escalation(
        frame_index=120,
        score=8.4,
        sync_count=5,
        dominant_freqs=[0.93, 1.07, 0.88, 1.12, 0.97]
    )
