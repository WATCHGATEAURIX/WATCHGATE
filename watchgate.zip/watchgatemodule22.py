# WATCHGATE MODULE 22: Live Stream Monitor & Visual Alert Engine
# ---------------------------------------------------------------
# This module acts as a visual surveillance monitor, analyzing fractal scores and symbolic detections in real-time.
# It overlays alert regions on live video feed where anomalous fractal patterns or symbolic clusters are detected.

import cv2
import numpy as np
from PIL import Image, ImageOps, ImageChops
from skimage.measure import shannon_entropy
import time

# === CONFIGURATION ===
ALERT_THRESHOLD = 6.0
FRAME_SAMPLE_RATE = 5
SHIFT_PIXELS = list(range(-6, 7, 2))

# === FRACTAL SCORE COMPUTATION ===
def fractal_score(image: Image.Image) -> float:
    array = np.array(image)
    return shannon_entropy(array)

# === SYMBOLIC REGION DETECTION ===
def detect_symbolic_regions(frame_gray):
    symbolic_map = np.zeros_like(frame_gray)
    h, w = frame_gray.shape
    tile_size = 64
    alert_zones = []

    for y in range(0, h - tile_size, tile_size):
        for x in range(0, w - tile_size, tile_size):
            tile = frame_gray[y:y+tile_size, x:x+tile_size]
            pil_tile = Image.fromarray(tile)
            mirrored = ImageOps.mirror(pil_tile)
            score_sum = 0

            for shift in SHIFT_PIXELS:
                shifted = ImageChops.offset(mirrored, shift, 0)
                combined = ImageChops.multiply(pil_tile, shifted)
                score_sum += fractal_score(combined)

            avg_score = score_sum / len(SHIFT_PIXELS)
            if avg_score > ALERT_THRESHOLD:
                alert_zones.append((x, y, tile_size, tile_size))
                symbolic_map[y:y+tile_size, x:x+tile_size] = 255

    return symbolic_map, alert_zones

# === LIVE VIDEO PROCESSOR ===
def run_stream_monitor():
    cap = cv2.VideoCapture(0)
    frame_index = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index % FRAME_SAMPLE_RATE == 0:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            symbolic_map, alerts = detect_symbolic_regions(gray)

            # Overlay alerts
            for (x, y, w, h) in alerts:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                cv2.putText(frame, "Symbolic", (x, y - 5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

        cv2.imshow("WATCHGATE - Live Monitor", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        frame_index += 1

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_stream_monitor()
