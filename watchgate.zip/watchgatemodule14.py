# WATCHGATE Module 14: Adaptive Entity Classification Engine
# ============================================================
# This module analyzes symbolic overlays and fractal patterns to adaptively classify potential symbolic entities.
# The system uses a dynamic memory structure to accumulate features over time and reclassify patterns.

import numpy as np
import uuid
from collections import deque

# === DYNAMIC ENTITY MEMORY STRUCTURE ===
class SymbolicEntity:
    def __init__(self, initial_features):
        self.id = str(uuid.uuid4())
        self.history = deque(maxlen=20)
        self.current_class = "unclassified"
        self.history.append(initial_features)

    def update(self, new_features):
        self.history.append(new_features)
        self.reclassify()

    def reclassify(self):
        avg_entropy = np.mean([f['entropy'] for f in self.history])
        peak_freqs = np.mean([np.max(f['frequencies']) for f in self.history])

        if avg_entropy > 6.0 and peak_freqs > 5000:
            self.current_class = "fractal-anomaly"
        elif avg_entropy > 5.0:
            self.current_class = "symbolic-entity"
        else:
            self.current_class = "noise"

    def __str__(self):
        return f"Entity {self.id[:8]} | Class: {self.current_class} | History: {len(self.history)}"

# === ENTITY TRACKER ===
class SymbolicEntityTracker:
    def __init__(self):
        self.entities = []

    def register_observation(self, features):
        matched = False
        for entity in self.entities:
            if self._similar(entity.history[-1], features):
                entity.update(features)
                matched = True
                break

        if not matched:
            self.entities.append(SymbolicEntity(features))

    def _similar(self, f1, f2):
        return abs(f1['entropy'] - f2['entropy']) < 1.0

    def summary(self):
        return [str(e) for e in self.entities]

# === EXAMPLE USAGE ===
if __name__ == "__main__":
    tracker = SymbolicEntityTracker()
    sample_frames = [
        {'entropy': 4.5, 'frequencies': [1000, 2000, 1500, 1300]},
        {'entropy': 5.5, 'frequencies': [2500, 2600, 2550]},
        {'entropy': 6.5, 'frequencies': [6000, 6100, 6050]},
    ]

    for f in sample_frames:
        tracker.register_observation(f)

    print("\n".join(tracker.summary()))
